def sayHello():
    print "Welcome to SC package"

