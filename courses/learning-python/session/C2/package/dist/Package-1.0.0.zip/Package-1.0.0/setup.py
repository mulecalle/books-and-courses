from distutils.core import setup

setup(
    name='Package',
    version='1.0.0',
    py_modules=['Welcome'],
    autor='SC',
    autor_email='sebacalle@gmail.com',
    url='sc.com',
    description='PackgeExample',
)
